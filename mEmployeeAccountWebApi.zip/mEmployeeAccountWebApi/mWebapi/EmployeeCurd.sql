
Create table Tbl_Employee(
EmployeeId int Identity Primary key,
EmpName varchar(100),
EmpEmailId  Varchar(150),
EmpPhoneno BigInt,
EmpAddress varchar(100));
 
 select * from Tbl_Employee;
 drop table Tbl_Employee;
 insert into Tbl_Employee values('Ashwini','ashwini1mallik@gmail.com',9940148772,'india');
 delete from Tbl_Employee where EmployeeId=3;